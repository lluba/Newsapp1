package com.example.joanna.newsapp;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class NewsAdapter extends ArrayAdapter<News> {


        public NewsAdapter(Context context, List<News> news) {
            super(context, 0, news);
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View listItemView = convertView;
            if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.news_list_item, parent, false);
            }

            News currentNews = getItem(position);

            String originalSection = currentNews.getSectionName();
            TextView sectionView = (TextView) listItemView.findViewById(R.id.section);
            sectionView.setText(currentNews.getSectionName());

            GradientDrawable newsCircle = (GradientDrawable) sectionView.getBackground();
            int sectionColor = getSectionColor(currentNews.getSectionName());
            newsCircle.setColor(sectionColor);

            Date dateObject = new Date(currentNews.getWebPublicationDate());
            TextView dateView = (TextView) listItemView.findViewById(R.id.date);
            String formattedDate = formatDate(dateObject);
            dateView.setText(formattedDate);

            String originalWebTitle = currentNews.getWebTitle();
            TextView txtLocation = (TextView) listItemView.findViewById(R.id.title);
            txtLocation.setText(currentNews.getWebTitle());

            return listItemView;
        }

        private int getSectionColor(String sectionName) {
           int magnitudeColorResourceId;
            switch (sectionName) {
                case "politics":
                    magnitudeColorResourceId = R.color.section1;
                    break;
                case "news":
                    magnitudeColorResourceId = R.color.section2;
                    break;
                case "business":
                    magnitudeColorResourceId = R.color.section3;
                    break;
                case "opinion":
                    magnitudeColorResourceId = R.color.section4;
                    break;
                default:
                    magnitudeColorResourceId = R.color.section4;
                    break;
            }

            return ContextCompat.getColor(getContext(), magnitudeColorResourceId);
        }

        private String formatDate(Date dateObject) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("LLL dd, yyyy");
            return dateFormat.format(dateObject);
        }

    }
