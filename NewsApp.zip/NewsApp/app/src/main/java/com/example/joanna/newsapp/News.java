package com.example.joanna.newsapp;

public class News {


        private String mSectionName;
        private long mWebPublicationDate;
        private String mWebTitle;
        public final String mUrl;



        public News(String sectionName, String webTitle, long webPublicationDate, String Url) {
            mSectionName = sectionName;
            mWebTitle = webTitle;
            mWebPublicationDate = webPublicationDate;
            mUrl = Url;
        }

        public String getSectionName() {return mSectionName;}

        public long getWebPublicationDate() {return mWebPublicationDate;}

        public String getWebTitle(){ return mWebTitle;}

        public String getUrl() {
            return mUrl;
        }

    }
